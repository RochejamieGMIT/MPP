This project includes three programs that read in the stock.csv file to stock a virtual test shop.
Procedural Python, Procedural C, and OOP python.

The shop has items, and a cash balance.
All the programs share the stock.csv file. 

********************************
Test Cases Explained
********************************
There is test cases for purchases for the programs. 
Clodagh, Dom, Jamie, Mike are all regular files that can be read and processed. 
The file kali.csv does not have enough money to pay for the times in their shopping basket. 
So kail's transcation can not be completed.
The file mary.csv has more items than are available in the shop. 
So mary's transcation can not be completed. 

There is a LiveBasket.csv in the directory also, this file takes in the users input during the live buying function.
And formats the data in the same way as the existing customers. This allows the reuse of the buying function for exisitng 
customers and live buying custiomers. 